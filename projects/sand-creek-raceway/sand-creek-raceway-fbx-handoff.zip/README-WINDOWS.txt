Sand Creek Raceway — FBX -> working kn5 (Windows)

WHY: the Mac-native pure-Python kn5 exporter (experimental, bundled in an AI-line
addon) does not produce valid AC track surfaces — the ground wouldn't render or
collide no matter what. This FBX is the same geometry run through the canonical
path so a real AC exporter can finish the job.

The FBX is verified: meshes named for AC (1ROAD_main, 1ROAD_connector, 1KERB_corners,
1GRASS, MARKINGS, BARRIER, BUILDINGS, ROOFS, TREES, WATER, HIGHWAY_visual, LIGHTS),
12 AC_* null markers placed (AC_START is on the start/finish), Y-up, textures in
sand_creek_raceway.fbm/.

OPTION A — ksEditor (AC SDK)
  1. ksEditor > File > Load > sand_creek_raceway.fbx
  2. Assign physics surfaces (match surfaces.ini here):
       1ROAD_main, 1ROAD_connector -> ROAD
       1KERB_corners               -> KERB
       1GRASS                      -> GRASS
     (leading-digit meshes are the physical/drivable ones)
  3. Assign shaders: ksPerPixelMultiMap (+diffuse/normal from the .fbm) for road/
     grass/buildings/roofs; ksTree for TREES; ksPerPixel for the rest.
  4. Check the AC_START / AC_PIT / AC_TIME nulls look right.
  5. Save + Export kn5.

OPTION B — Blender + "AC Blender Tools" (ksTools) addon, Blender 4.x
  Install the addon, open the project, then:
     blender --background --python scripts/ac/build_kn5.py -- projects/sand-creek-raceway
  build_kn5.py auto-detects the addon's kn5 export operator and writes a real kn5
  (no ksEditor needed). A ready blender/sand_creek_raceway.blend is also in the repo.

INSTALL THE RESULT
  Put the exported kn5 here, replacing the broken one:
     .../assettocorsa/content/tracks/sand_creek_raceway/sand_creek_raceway.kn5
  Everything else in that folder (surfaces.ini, ui/, models_full.ini, map) is already
  correct from release v0.1.4. Load "Sand Creek Raceway - full" and drive.
